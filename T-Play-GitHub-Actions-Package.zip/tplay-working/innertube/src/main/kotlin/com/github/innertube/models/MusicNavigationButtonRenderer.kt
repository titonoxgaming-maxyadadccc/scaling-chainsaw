package com.github.innertube.models

import kotlinx.serialization.Serializable

@Serializable
data class MusicNavigationButtonRenderer(
    val buttonText: Runs? = null,
    val solid: Solid? = null,
    val iconStyle: IconStyle? = null,
    val clickCommand: NavigationEndpoint? = null,
) {
    @Serializable
    data class Solid(val leftStripeColor: Long? = null)

    @Serializable
    data class IconStyle(val icon: Icon? = null)

    @Serializable
    data class Icon(val iconType: String? = null)
}
