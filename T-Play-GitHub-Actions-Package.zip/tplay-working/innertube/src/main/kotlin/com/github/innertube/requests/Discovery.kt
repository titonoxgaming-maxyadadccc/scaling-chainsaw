package com.github.innertube.requests

import com.github.innertube.Innertube
import com.github.innertube.models.BrowseResponse
import com.github.innertube.models.MusicResponsiveListItemRenderer
import com.github.innertube.models.MusicTwoRowItemRenderer
import com.github.innertube.models.SectionListRenderer
import com.github.innertube.models.bodies.BrowseBody
import com.github.innertube.utils.from
import io.ktor.client.call.body
import io.ktor.client.request.post
import io.ktor.client.request.setBody

/** YouTube Music's editorial new-release page. */
suspend fun Innertube.newReleaseShelves(): Result<List<Innertube.DiscoveryShelf>> =
    discoveryShelves(browseId = "FEmusic_new_releases")

/** YouTube Music charts. The same endpoint is used by the official music web client. */
suspend fun Innertube.chartShelves(): Result<List<Innertube.DiscoveryShelf>> =
    discoveryShelves(browseId = "FEmusic_charts", params = "ggMGCgQIgAQ%3D")

/** Browse a mood/genre page selected from the YouTube Music Explore catalogue. */
suspend fun Innertube.discoveryShelves(
    browseId: String,
    params: String? = null,
): Result<List<Innertube.DiscoveryShelf>> = runCatching {
    val response = client.post(BROWSE) {
        setBody(BrowseBody(browseId = browseId, params = params))
    }.body<BrowseResponse>()

    val sectionList = response.contents
        ?.singleColumnBrowseResultsRenderer
        ?.tabs
        ?.firstOrNull()
        ?.tabRenderer
        ?.content
        ?.sectionListRenderer
        ?: response.contents?.sectionListRenderer

    sectionList?.contents.orEmpty().mapNotNull(::toDiscoveryShelf).filter { it.items.isNotEmpty() }
}

/** YouTube Music's public moods and genres catalogue. */
suspend fun Innertube.moodsAndGenres(): Result<List<Innertube.MoodCategory>> = runCatching {
    val response = client.post(BROWSE) {
        setBody(BrowseBody(browseId = "FEmusic_moods_and_genres"))
    }.body<BrowseResponse>()

    val sections = response.contents
        ?.singleColumnBrowseResultsRenderer
        ?.tabs
        ?.firstOrNull()
        ?.tabRenderer
        ?.content
        ?.sectionListRenderer
        ?.contents.orEmpty()

    sections.mapNotNull sectionLoop@{ section ->
        val grid = section.gridRenderer ?: return@sectionLoop null
        val title = grid.header?.gridHeaderRenderer?.title?.text
            ?: section.musicResponsiveHeaderRenderer?.title?.text
            ?: return@sectionLoop null

        val items = grid.items.orEmpty().mapNotNull itemLoop@{ item ->
            val renderer = item.musicNavigationButtonRenderer ?: return@itemLoop null
            val endpoint = renderer.clickCommand?.browseEndpoint ?: return@itemLoop null
            val browseId = endpoint.browseId ?: return@itemLoop null
            val moodTitle = renderer.buttonText?.text?.takeIf(String::isNotBlank)
                ?: return@itemLoop null
            Innertube.MoodItem(
                title = moodTitle,
                browseId = browseId,
                params = endpoint.params,
                stripeColor = renderer.solid?.leftStripeColor,
            )
        }.distinctBy { it.browseId to it.params }
        Innertube.MoodCategory(title = title, items = items).takeIf { items.isNotEmpty() }
    }
}

private fun toDiscoveryShelf(
    section: SectionListRenderer.Content,
): Innertube.DiscoveryShelf? {
    val title = section.musicCarouselShelfRenderer
        ?.header?.musicCarouselShelfBasicHeaderRenderer?.title?.text
        ?: section.musicShelfRenderer?.title?.text
        ?: section.gridRenderer?.header?.gridHeaderRenderer?.title?.text
        ?: section.musicResponsiveHeaderRenderer?.title?.text
        ?: return null

    val entries = buildList<Innertube.DiscoveryEntry> {
        section.musicCarouselShelfRenderer?.contents.orEmpty().forEach { item ->
            item.musicResponsiveListItemRenderer?.let { addSong(it) }
            item.musicTwoRowItemRenderer?.let { addTwoRow(it) }
        }
        section.musicShelfRenderer?.contents.orEmpty().forEach { item ->
            item.musicResponsiveListItemRenderer?.let { addSong(it) }
        }
        section.gridRenderer?.items.orEmpty().forEach { item ->
            item.musicTwoRowItemRenderer?.let { addTwoRow(it) }
        }
    }.distinctBy { entry -> entry.song?.info?.endpoint?.videoId ?: entry.browseId ?: entry.title }

    return Innertube.DiscoveryShelf(title = title, items = entries).takeIf { entries.isNotEmpty() }
}

private fun MutableList<Innertube.DiscoveryEntry>.addSong(
    renderer: MusicResponsiveListItemRenderer,
) {
    val song = Innertube.SongItem.from(renderer) ?: return
    if (song.info?.endpoint?.videoId == null) return
    add(
        Innertube.DiscoveryEntry(
            kind = Innertube.DiscoveryEntry.Kind.SONG,
            title = song.info?.name.orEmpty(),
            subtitle = song.authors?.joinToString(", ") { it.name.orEmpty() },
            thumbnailUrl = song.thumbnail?.url,
            song = song,
        ),
    )
}

private fun MutableList<Innertube.DiscoveryEntry>.addTwoRow(
    renderer: MusicTwoRowItemRenderer,
) {
    val titleRun = renderer.title?.runs?.firstOrNull()
    val endpoint = titleRun?.navigationEndpoint?.browseEndpoint
        ?: renderer.navigationEndpoint?.browseEndpoint
        ?: return
    val browseId = endpoint.browseId ?: return
    val pageType = endpoint.type.orEmpty().uppercase()
    val kind = when {
        pageType.contains("ARTIST") || browseId.startsWith("UC") -> Innertube.DiscoveryEntry.Kind.ARTIST
        pageType.contains("ALBUM") || browseId.startsWith("MPRE") || browseId.startsWith("MPLA") -> Innertube.DiscoveryEntry.Kind.ALBUM
        else -> Innertube.DiscoveryEntry.Kind.PLAYLIST
    }
    val thumbnail = renderer.thumbnailRenderer
        ?.musicThumbnailRenderer?.thumbnail?.thumbnails
        ?.maxByOrNull { it.width ?: 0 }?.url

    add(
        Innertube.DiscoveryEntry(
            kind = kind,
            title = titleRun?.text.orEmpty(),
            subtitle = renderer.subtitle?.text,
            thumbnailUrl = thumbnail,
            browseId = browseId,
            params = endpoint.params,
        ),
    )
}
