package com.github.musicyou.ui.styling

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color as AndroidColor
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.github.musicyou.enums.AlbumAccentMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL
import kotlin.math.abs
import kotlin.math.max

/**
 * Process-wide accent sampled from the currently playing track's artwork.
 * MaterialTheme observes this state and updates the app accent without
 * changing the app's dark/AMOLED background.
 */
object AlbumArtworkPalette {
    var accent by mutableStateOf(Color(0xFFB9A4FF))
        private set

    fun update(color: Color) {
        accent = color
    }
}

object AlbumAccentModeState {
    var mode by mutableStateOf(AlbumAccentMode.Artwork)
    var initialized: Boolean = false
}

/** Small in-memory cache so the mini player, full player and playlist/artist pages never download and decode the same artwork repeatedly. */
private val accentCache = object : LinkedHashMap<String, Color>(32, 0.75f, true) {
    override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Color>?): Boolean = size > 48
}

/** Reads a tiny thumbnail and extracts a saturated mid-tone without adding a DSP/palette dependency. */
suspend fun extractAlbumAccent(context: Context, uri: Uri?): Color? = withContext(Dispatchers.IO) {
    if (uri == null) return@withContext null

    val cacheKey = uri.toString()
    synchronized(accentCache) { accentCache[cacheKey] }?.let { return@withContext it }

    val extracted: Color? = try {
        val input = when (uri.scheme?.lowercase()) {
            "http", "https" -> URL(uri.toString()).openConnection().apply {
                connectTimeout = 8_000
                readTimeout = 8_000
                setRequestProperty("User-Agent", "TPlay/1.0")
            }.getInputStream()
            else -> context.contentResolver.openInputStream(uri)
        } ?: return@withContext null

        val bitmap = input.use {
            BitmapFactory.decodeStream(
                it,
                null,
                BitmapFactory.Options().apply { inSampleSize = 8 }
            )
        } ?: return@withContext null

        try {
            val hsv = FloatArray(3)
            var red = 0.0
            var green = 0.0
            var blue = 0.0
            var totalWeight = 0.0
            val stepX = max(1, bitmap.width / 32)
            val stepY = max(1, bitmap.height / 32)

            for (y in 0 until bitmap.height step stepY) {
                for (x in 0 until bitmap.width step stepX) {
                    val pixel = bitmap.getPixel(x, y)
                    if (AndroidColor.alpha(pixel) < 180) continue
                    AndroidColor.colorToHSV(pixel, hsv)
                    val saturation = hsv[1]
                    val value = hsv[2]
                    if (saturation < 0.18f || value < 0.14f || value > 0.94f) continue

                    val weight = saturation * (1.0f - abs(value - 0.56f) * 0.7f)
                    red += AndroidColor.red(pixel) * weight
                    green += AndroidColor.green(pixel) * weight
                    blue += AndroidColor.blue(pixel) * weight
                    totalWeight += weight
                }
            }

            if (totalWeight <= 0.0) return@withContext null

            Color(
                red = (red / totalWeight / 255.0).toFloat().coerceIn(0f, 1f),
                green = (green / totalWeight / 255.0).toFloat().coerceIn(0f, 1f),
                blue = (blue / totalWeight / 255.0).toFloat().coerceIn(0f, 1f),
                alpha = 1f
            )
        } finally {
            bitmap.recycle()
        }
    } catch (_: Exception) {
        null
    }

    if (extracted != null) synchronized(accentCache) { accentCache[cacheKey] = extracted }
    extracted
}
