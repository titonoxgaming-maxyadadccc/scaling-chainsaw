package com.github.musicyou.ui.components

import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.github.musicyou.R
import com.github.musicyou.enums.NavigationLabelsVisibility
import com.github.musicyou.ui.navigation.Routes
import com.github.musicyou.ui.navigation.TopDestinations
import com.github.musicyou.utils.rememberPreference
import com.github.musicyou.utils.homeScreenTabIndexKey
import com.github.musicyou.utils.navigationLabelsVisibilityKey
import dev.lelonio.square.ui.glass.LiquidBottomTab
import dev.lelonio.square.ui.glass.LiquidBottomTabs
import dev.lelonio.square.ui.glass.backdrop.Backdrop

private const val bottomNavigationOrderKey = "tPlayLiquidBottomNavigationOrder"
private const val lastNavigationTabKey = "tPlayLastNavigationTab"

/** Square-derived liquid-glass navigation: tap, swipe the selector, or long-press to reorder. */
@Composable
fun BottomNavigation(navController: NavHostController, backdrop: Backdrop) {
    val entry by navController.currentBackStackEntryAsState()
    val destination = entry?.destination

    val destinationIds = remember { TopDestinations.list.map { it.resourceId.toString() } }
    val defaultOrder = remember { destinationIds.joinToString(",") }
    var savedOrder by rememberPreference(bottomNavigationOrderKey, defaultOrder)
    val orderedIds = remember(savedOrder, destinationIds) {
        val valid = savedOrder.split(',').filter { it in destinationIds }.distinct()
        valid + destinationIds.filterNot { it in valid }
    }
    val orderState = rememberUpdatedState(orderedIds)
    val destinationsById = remember(destinationIds) {
        TopDestinations.list.associateBy { it.resourceId.toString() }
    }

    val directActiveId = TopDestinations.list.firstOrNull { item ->
        destination?.hierarchy?.any { it.hasRoute(route = item.route::class) } == true
    }?.resourceId?.toString()
    val isLibraryChild = destination?.hierarchy?.any { child ->
        child.hasRoute(Routes.Songs::class) ||
            child.hasRoute(Routes.Artists::class) ||
            child.hasRoute(Routes.Albums::class) ||
            child.hasRoute(Routes.Playlists::class)
    } == true
    val activeId = directActiveId ?: if (isLibraryChild) {
        TopDestinations.list.firstOrNull { it.route == Routes.Library }?.resourceId?.toString()
    } else null

    var lastSelectedId by rememberPreference(lastNavigationTabKey, destinationIds.first())
    var homeScreenTabIndex by rememberPreference(homeScreenTabIndexKey, 0)
    var navigationLabelsVisibility by rememberPreference(
        navigationLabelsVisibilityKey,
        NavigationLabelsVisibility.Visible,
    )
    LaunchedEffect(activeId) {
        if (activeId != null) lastSelectedId = activeId
    }
    val selectedIndex = orderedIds.indexOf(lastSelectedId).coerceAtLeast(0)
    val selectedIndexState = rememberUpdatedState(selectedIndex)
    val selectedTabIndex = remember { { selectedIndexState.value } }

    var draggingId by remember { mutableStateOf<String?>(null) }
    val haptics = LocalHapticFeedback.current
    val reorderState = rememberUpdatedState<(Int, Int) -> Unit> { from, to ->
        val next = orderState.value.toMutableList()
        if (from in next.indices && to in next.indices && from != to) {
            next.add(to, next.removeAt(from))
            savedOrder = next.joinToString(",")
        }
    }

    // MainActivity provides the live, preference-backed GlassEffectConfig.
    // Do not replace it here: the dock must respond to Appearance settings.
    Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(start = 12.dp, end = 12.dp, top = 5.dp, bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(0.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .pointerInput(Unit) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { position ->
                                val ids = orderState.value
                                val itemWidth = size.width.toFloat() / ids.size.coerceAtLeast(1)
                                val index = (position.x / itemWidth).toInt().coerceIn(ids.indices)
                                draggingId = ids.getOrNull(index)
                                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                val dragged = draggingId ?: return@detectDragGesturesAfterLongPress
                                val ids = orderState.value
                                val itemWidth = size.width.toFloat() / ids.size.coerceAtLeast(1)
                                val target = (change.position.x / itemWidth).toInt().coerceIn(ids.indices)
                                val from = ids.indexOf(dragged)
                                if (from >= 0 && target != from) {
                                    reorderState.value(from, target)
                                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                }
                            },
                            onDragEnd = { draggingId = null },
                            onDragCancel = { draggingId = null },
                        )
                    },
                contentAlignment = Alignment.Center,
            ) {
                LiquidBottomTabs(
                    selectedTabIndex = selectedTabIndex,
                    onTabSelected = { index ->
                        val id = orderState.value.getOrNull(index) ?: return@LiquidBottomTabs
                        if (id == activeId && activeId != null) return@LiquidBottomTabs
                        val item = destinationsById[id] ?: return@LiquidBottomTabs
                        lastSelectedId = id
                        homeScreenTabIndex = TopDestinations.list.indexOfFirst { it.resourceId.toString() == id }.coerceAtLeast(0)
                        navController.navigate(item.route) {
                            popUpTo(navController.graph.findStartDestination().id)
                            launchSingleTop = true
                        }
                    },
                    backdrop = backdrop,
                    tabsCount = orderedIds.size,
                    accentColor = MaterialTheme.colorScheme.primary,
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.22f),
                    height = 66.dp,
                    lensDepth = 24.dp,
                    indicatorVisible = activeId != null,
                    indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.20f),
                    allowDragSelection = false,
                ) {
                    orderedIds.forEach { id ->
                        val item = destinationsById[id] ?: return@forEach
                        key(id) {
                            val isSelected = id == lastSelectedId && activeId != null
                            val isDragging = id == draggingId
                            LiquidBottomTab(
                                onClick = {
                                    lastSelectedId = id
                                    homeScreenTabIndex = TopDestinations.list.indexOfFirst { it.resourceId.toString() == id }.coerceAtLeast(0)
                                    navController.navigate(item.route) {
                                        popUpTo(navController.graph.findStartDestination().id)
                                        launchSingleTop = true
                                    }
                                },
                                modifier = Modifier.graphicsLayer {
                                    val scale = if (isDragging) 1.12f else 1f
                                    scaleX = scale
                                    scaleY = scale
                                    translationY = if (isDragging) -5.dp.toPx() else 0f
                                    shadowElevation = if (isDragging) 12.dp.toPx() else 0f
                                },
                            ) {
                                Icon(
                                    imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                    contentDescription = stringResource(item.resourceId),
                                    tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.82f),
                                    modifier = Modifier.size(22.dp),
                                )
                                if (navigationLabelsVisibility == NavigationLabelsVisibility.Visible ||
                                    (navigationLabelsVisibility == NavigationLabelsVisibility.VisibleWhenActive && isSelected)
                                ) {
                                    Text(
                                        text = stringResource(item.resourceId),
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.84f),
                                        fontSize = 10.sp,
                                        lineHeight = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
}
