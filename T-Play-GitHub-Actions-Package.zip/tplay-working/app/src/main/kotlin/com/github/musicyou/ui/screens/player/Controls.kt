package com.github.musicyou.ui.screens.player

import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Equalizer
import androidx.compose.material.icons.outlined.RepeatOne
import androidx.compose.material.icons.outlined.SkipNext
import androidx.compose.material.icons.outlined.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.stringResource
import dev.lelonio.square.ui.glass.LiquidButton
import dev.lelonio.square.ui.glass.LocalGlassEffectConfig
import dev.lelonio.square.ui.glass.liquidGlass
import dev.lelonio.square.ui.glass.backdrop.Backdrop
import androidx.media3.common.C
import androidx.media3.common.Player
import com.github.musicyou.LocalPlayerServiceBinder
import com.github.musicyou.R
import com.github.musicyou.database
import com.github.musicyou.models.Song
import com.github.musicyou.ui.components.SeekBar
import com.github.musicyou.ui.styling.Dimensions
import com.github.musicyou.utils.forceSeekToNext
import com.github.musicyou.utils.forceSeekToPrevious
import com.github.musicyou.utils.formatAsDuration
import com.github.musicyou.utils.rememberPreference
import com.github.musicyou.utils.trackLoopEnabledKey
import kotlinx.coroutines.flow.distinctUntilChanged

@Composable
fun Controls(
    glassBackdrop: Backdrop,
    mediaId: String,
    title: String,
    artist: String,
    onShowLyrics: () -> Unit,
    onShowEffects: () -> Unit,
    shouldBePlaying: Boolean,
    position: Long,
    duration: Long,
    onGoToArtist: (() -> Unit)?,
    modifier: Modifier = Modifier
) {
    val binder = LocalPlayerServiceBinder.current
    binder?.player ?: return

    var trackLoopEnabled by rememberPreference(trackLoopEnabledKey, defaultValue = false)
    var scrubbingPosition by remember(mediaId) { mutableStateOf<Long?>(null) }
    var likedAt by rememberSaveable { mutableStateOf<Long?>(null) }
    LaunchedEffect(mediaId) {
        database.likedAt(mediaId).distinctUntilChanged().collect { likedAt = it }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp)
    ) {
        Spacer(
            modifier = Modifier.weight(1f)
        )

        val titleShape = RoundedCornerShape(22.dp)
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .liquidGlass(
                    config = LocalGlassEffectConfig.current.copy(
                        blurRadius = 12f,
                        lensHeight = 0.38f,
                        lensAmount = 0.45f,
                        surfaceOpacity = 0.19f,
                    ),
                    shape = titleShape,
                    blurRadiusDp = 12f,
                    highlightAlpha = 0.22f,
                    ownBackdrop = glassBackdrop,
                )
                .padding(horizontal = 16.dp, vertical = 11.dp)
        ) {
            Text(
                text = title,
                modifier = Modifier.basicMarquee(),
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1
            )
            Text(
                text = artist,
                modifier = Modifier.clickable(
                    enabled = onGoToArtist != null,
                    onClick = onGoToArtist ?: {}
                ),
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(
            modifier = Modifier.weight(0.5f)
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onShowLyrics) {
                Text(
                    text = stringResource(R.string.lyrics),
                    color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.labelLarge
                )
            }
            TextButton(onClick = onShowEffects) {
                Icon(Icons.Outlined.Equalizer, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.effects),
                    color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }

        SeekBar(
            value = scrubbingPosition ?: position,
            minimumValue = 0,
            maximumValue = duration,
            onDragStart = {
                scrubbingPosition = it
            },
            onDrag = { delta ->
                scrubbingPosition = if (duration != C.TIME_UNSET) {
                    scrubbingPosition?.plus(delta)?.coerceIn(0, duration)
                } else {
                    null
                }
            },
            onDragEnd = {
                scrubbingPosition?.let(binder.player::seekTo)
                scrubbingPosition = null
            },
            color = MaterialTheme.colorScheme.primary,
            backgroundColor = MaterialTheme.colorScheme.primaryContainer,
            shape = RoundedCornerShape(8.dp)
        )

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = formatAsDuration(scrubbingPosition ?: position),
                style = MaterialTheme.typography.labelMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )

            if (duration != C.TIME_UNSET) {
                Text(
                    text = formatAsDuration(duration),
                    style = MaterialTheme.typography.labelMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }

        Spacer(
            modifier = Modifier.weight(1f)
        )

        Row(
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            LiquidButton(
                onClick = {
                    val currentMediaItem = binder.player.currentMediaItem
                    database.query {
                        if (database.like(
                                mediaId,
                                if (likedAt == null) System.currentTimeMillis() else null
                            ) == 0
                        ) {
                            currentMediaItem
                                ?.takeIf { it.mediaId == mediaId }
                                ?.let { database.insert(currentMediaItem, Song::toggleLike) }
                        }
                    }
                },
                backdrop = glassBackdrop,
                modifier = Modifier.size(46.dp),
                shape = CircleShape,
                contentHeight = 46.dp,
                contentPadding = 0.dp,
                surfaceColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
            ) {
                Icon(
                    imageVector = if (likedAt == null) Icons.Outlined.FavoriteBorder else Icons.Filled.Favorite,
                    contentDescription = "Like",
                    modifier = Modifier.size(22.dp),
                    tint = MaterialTheme.colorScheme.error,
                )
            }

            LiquidButton(
                onClick = binder.player::forceSeekToPrevious,
                backdrop = glassBackdrop,
                modifier = Modifier.size(46.dp),
                shape = CircleShape,
                contentHeight = 46.dp,
                contentPadding = 0.dp,
            ) {
                Icon(
                    imageVector = Icons.Outlined.SkipPrevious,
                    contentDescription = "Previous track",
                    modifier = Modifier.size(25.dp),
                )
            }

            LiquidButton(
                onClick = {
                    if (shouldBePlaying) binder.player.pause()
                    else {
                        if (binder.player.playbackState == Player.STATE_IDLE) {
                            binder.player.prepare()
                        } else if (binder.player.playbackState == Player.STATE_ENDED) {
                            binder.player.seekToDefaultPosition(0)
                        }
                        binder.player.play()
                    }
                },
                backdrop = glassBackdrop,
                modifier = Modifier.size(66.dp),
                shape = CircleShape,
                contentHeight = 66.dp,
                contentPadding = 0.dp,
                surfaceColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
            ) {
                Icon(
                    imageVector = if (shouldBePlaying) Icons.Filled.Pause
                    else if (binder.player.playbackState == Player.STATE_ENDED) Icons.Filled.Replay
                    else Icons.Filled.PlayArrow,
                    contentDescription = if (shouldBePlaying) "Pause" else "Play",
                    modifier = Modifier.size(30.dp),
                    tint = Color.White,
                )
            }

            LiquidButton(
                onClick = binder.player::forceSeekToNext,
                backdrop = glassBackdrop,
                modifier = Modifier.size(46.dp),
                shape = CircleShape,
                contentHeight = 46.dp,
                contentPadding = 0.dp,
            ) {
                Icon(
                    imageVector = Icons.Outlined.SkipNext,
                    contentDescription = "Next track",
                    modifier = Modifier.size(25.dp),
                )
            }

            LiquidButton(
                onClick = { trackLoopEnabled = !trackLoopEnabled },
                backdrop = glassBackdrop,
                modifier = Modifier.size(46.dp),
                shape = CircleShape,
                contentHeight = 46.dp,
                contentPadding = 0.dp,
                tint = if (trackLoopEnabled) MaterialTheme.colorScheme.primary else Color.Unspecified,
            ) {
                Icon(
                    imageVector = Icons.Outlined.RepeatOne,
                    contentDescription = "Repeat one",
                    modifier = Modifier
                        .alpha(if (trackLoopEnabled) 1F else Dimensions.lowOpacity)
                        .size(22.dp),
                )
            }
        }

        Spacer(
            modifier = Modifier.weight(1f)
        )
    }
}