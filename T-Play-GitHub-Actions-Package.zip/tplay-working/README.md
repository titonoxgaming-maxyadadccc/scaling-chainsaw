# TITONOX PLAYER (T PLAY)

A YouTube Music-powered Android music player with a customizable liquid-glass interface.

**App version:** 1.5.0 (version code 22)

## Build

Use Android Studio with JDK 21 for the Gradle daemon and the Android SDK (platform API 37). Open this project folder and run the `app` debug configuration, or run:

```bash
./gradlew :app:assembleDebug
```

The debug APK is written to `app/build/outputs/apk/debug/`. The `TITONOX PLAYER Android APK` workflow is included at `.github/workflows/build-apk.yml`.

## Current UI features

- Device audio library using Android MediaStore permission flow
- Long-press a local device audio track to copy it into T Play's private storage
- In-app Downloads list for those private copies (never saved to the public Downloads folder)
- Queue-aware crossfade (default ON; configurable 2–6 seconds, default 4 seconds)
- YouTube streams remain streaming sources; the app does not export YouTube Music streams to MP3

- TITONOX PLAYER app label and custom launcher identity
- Five primary navigation destinations
- Artwork-aware accent colors with manual color choices
- Synchronized lyrics where timestamped lyrics are available
- In-player speed, pitch, bass boost and reverb controls (device audio-effect support varies)
- Custom TTF/OTF font import
- Liquid-glass surfaces and player controls
- Preference-backed glass tuning shared by the dock and player UI
- Scroll-edge fade on Home, Discovery, Search, Library and Settings content
- About page with creator credit and TITONOX OFFICIAL social links

## Licensing

This source includes GPL-licensed upstream components and separately licensed glass/backdrop code. Keep the included `LICENSE`, `LICENSE-SQUARE.txt`, `LICENSE-backdrop.txt`, `LICENSE-liquid-glass.txt`, and `THIRD_PARTY_NOTICES.txt` files with redistributed source/binaries as required by their terms.
